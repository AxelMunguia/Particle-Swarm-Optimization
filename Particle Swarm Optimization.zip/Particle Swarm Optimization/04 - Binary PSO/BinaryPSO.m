clear all;
close all;

% Define the details of the objective function
nVar = 20;
ub = ones(1, nVar);
lb = zeros(1,nVar);
fobj = @ObjectiveFunction; 

% Define the PSO's parameters
noP = 50;
maxIter = 5000;
wMax = 0.9;
wMin = 0.2;
c1 = 2;
c2 = 2;
vMax = (ub - lb) .* 0.2;
vMin = -vMax;


% PSO Algorithm

% Initialize the particles
for k=1:noP
    % Update Each Particle
    Swarm.Particles(k).X = round((ub - lb) .* rand(1, nVar) + lb);
    Swarm.Particles(k).V = zeros(1, nVar);
    Swarm.Particles(k).PBEST.X = zeros(1, nVar);
    Swarm.Particles(k).PBEST.O = inf;
    
    % Update GBEST if needed
    Swarm.GBEST.X = zeros(1, nVar);
    Swarm.GBEST.O = inf;
end

% Main Loop
for t=1:maxIter
   
    % Calculate the Objective Value
    for k=1:noP
        % Current Particle
        currentX = Swarm.Particles(k).X;
        Swarm.Particles(k).O = fobj(currentX);
        
        % Update PBest
        if Swarm.Particles(k).O < Swarm.Particles(k).PBEST.O
            Swarm.Particles(k).PBEST.X = currentX;
            Swarm.Particles(k).PBEST.O = Swarm.Particles(k).O;
        end
        
        % Update the GBEST
        if Swarm.Particles(k).O < Swarm.GBEST.O
            Swarm.GBEST.X = currentX;
            Swarm.GBEST.O =  Swarm.Particles(k).O;
        end
    end
    
    % Update the X and V Vectors
    w = wMax - t .* ((wMax - wMin)/maxIter); % Decreasing Weight
    for k=1:noP
        % $V_i^{t+1} = w\vec{V_i^{t}} + c_1 r_1 (\vec{P_i^{t}} - \vec{X_i^{t}}) +  c_2 r_1 (\vec{G^{t}} - \vec{X_i^{t}})$
        Swarm.Particles(k).V = w.*Swarm.Particles(k).V + c1 .* rand(1, nVar) .* (Swarm.Particles(k).PBEST.X - Swarm.Particles(k).X)...
                                                       + c2 .* rand(1, nVar) .* (Swarm.GBEST.X - Swarm.Particles(k).X);
        % Restrict major Changes
        index1 = find(Swarm.Particles(k).V > vMax);
        index2 = find(Swarm.Particles(k).V < vMin);
        % Change Velocities
        Swarm.Particles(k).V(index1) = vMax(index1);
        Swarm.Particles(k).V(index2) = vMin(index2);
        
        % Sigmoid Transfer Functin $T(\overrightarrow{V_i^{t+1}}) = \frac{1}{1 + e^{-\overrightarrow{V_i^{t+1}}}}$
        s = 1 ./ (1 + exp(-Swarm.Particles(k).V));

        % Update the position of k-th particle
        for d=1:nVar
            r = rand();
            if r<s(d)
                Swarm.Particles(k).X(d) = 1;
            else
                Swarm.Particles(k).X(d) = 0;
            end
        end
    end
    
    outmsg = ["Iteraction#", num2str(t), "Swarm.GBEST.O =", num2str(Swarm.GBEST.O)];
    display(outmsg);
    
    % Save Each Swarm.GBEST.O
    cgCurve(t) = Swarm.GBEST.O;
    
end

semilogy(cgCurve);
