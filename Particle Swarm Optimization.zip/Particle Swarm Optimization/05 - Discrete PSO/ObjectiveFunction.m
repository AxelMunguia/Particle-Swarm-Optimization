function [o] = ObjectiveFunction( x )
    Discrete_set = [10, 20, 30, 40];
    D_x = zeros(1, 5);
    
    idx = 0;
    for k=1:2:length(x)
        idx = idx + 1;
        if x(k) == 0 && x(k+1) == 0
            D_x(idx) = Discrete_set(1);
        elseif x(k) == 0 && x(k+1) == 1
            D_x(idx) = Discrete_set(2);
        elseif x(k) == 1 && x(k+1) == 0
            D_x(idx) = Discrete_set(3);
        elseif x(k) == 1 && x(k+1) == 1
            D_x(idx) = Discrete_set(4);
        end
    end
    o = sum( D_x.^2 ); % Sphere Test Function
    
end