function [o] = SphereWithConstrains( x ) 
    
    % Constrains
    const1 = x(2)<=3.2 || x(2)>=6.4;
    const2 = (x(1).^2 + x(2).^2) >= 1;
    const3 = x(1) ~= x(2);
    
    if const1== 1 && const2 == 1 && const3 == 1
        % Feasible Solutions
        o = sum(x.^2); % Sphere test function
    else 
        % Infeasible Solutions
        o = sum(x.^2) + 200;
    end

end

