clear all;
close all;

% Define the details of the objective function
nVar = 2;
ub = [ 10  10 ];
lb = [-10 -10 ];
fobj = @SphereWithConstrains; 

% Define the PSO's parameters
noP = 30;
maxIter = 500;
wMax = 0.9;
wMin = 0.2;
c1 = 2;
c2 = 2;
vMax = (ub - lb) .* 0.2;
vMin = -vMax;


% PSO Algorithm

% Initialize the particles
for k=1:noP
    % Update Each Particle
    Swarm.Particles(k).X = (ub - lb) .* rand(1, nVar) + lb;
    Swarm.Particles(k).V = zeros(1, nVar);
    Swarm.Particles(k).PBEST.X = zeros(1, nVar);
    Swarm.Particles(k).PBEST.O = inf;
    
    % Update GBEST if needed
    Swarm.GBEST.X = zeros(1, nVar);
    Swarm.GBEST.O = inf;
end

% Main Loop
for t=1:maxIter
   
    % Calculate the Objective Value
    for k=1:noP
        % Current Particle
        currentX = Swarm.Particles(k).X;
        Swarm.Particles(k).O = fobj(currentX);
        
        % Update PBest
        if Swarm.Particles(k).O < Swarm.Particles(k).PBEST.O;
            Swarm.Particles(k).PBEST.X = currentX;
            Swarm.Particles(k).PBEST.O = Swarm.Particles(k).O;
        end
        
        % Update the GBEST
        if Swarm.Particles(k).O < Swarm.GBEST.O
            Swarm.GBEST.X = currentX;
            Swarm.GBEST.O =  Swarm.Particles(k).O;
        end
    end
    
    % Update the X and V Vectors
    w = wMax - t .* ((wMax - wMin)/maxIter); % Decreasing Weight
    for k=1:noP
        % $V_i^{t+1} = w\vec{V_i^{t}} + c_1 r_1 (\vec{P_i^{t}} - \vec{X_i^{t}}) +  c_2 r_1 (\vec{G^{t}} - \vec{X_i^{t}})$
        Swarm.Particles(k).V = w.*Swarm.Particles(k).V + c1 .* rand(1, nVar) .* (Swarm.Particles(k).PBEST.X - Swarm.Particles(k).X)...
                                                       + c2 .* rand(1, nVar) .* (Swarm.GBEST.X - Swarm.Particles(k).X);
        % Restrict major Changes
        index1 = find(Swarm.Particles(k).V > vMax);
        index2 = find(Swarm.Particles(k).V < vMin);
        % Change Velocities
        Swarm.Particles(k).V(index1) = vMax(index1);
        Swarm.Particles(k).V(index2) = vMin(index2);
        
        % Update Velocity
        Swarm.Particles(k).X = Swarm.Particles(k).X + Swarm.Particles(k).V;
        
        % Restrict Positions Outside Borders
        index1 = find(Swarm.Particles(k).X > ub);
        index2 = find(Swarm.Particles(k).X < lb);
        % Change Positions
        Swarm.Particles(k).X(index1) = ub(index1);
        Swarm.Particles(k).X(index2) = lb(index2);
        
    end
    
    outmsg = ["Iteraction#", num2str(t), "Swarm.GBEST.O =", num2str(Swarm.GBEST.O)];
    display(outmsg);
    
    % Save Each Swarm.GBEST.O
    cgCurve(t) = Swarm.GBEST.O;
    
end

semilogy(cgCurve);
