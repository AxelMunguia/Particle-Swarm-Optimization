function [weight] = OurTableDesignProblem(x)
    % Position No. 1 equals length and position No. 2 equals Width.
    length = x(1);
    width = x(2);
    % Minimize funtion 1*(length * width)
    weight = 1*(length + width);
end