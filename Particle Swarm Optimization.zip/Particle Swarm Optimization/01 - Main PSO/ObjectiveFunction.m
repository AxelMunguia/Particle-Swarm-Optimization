function [o] = ObjectiveFunction( x )
    o = sum( x.^2 ); % Sphere Test Function
end