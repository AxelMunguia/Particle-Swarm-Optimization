function [expected_objective] = ExpectedObjectiveFunction(x)

    i = 0.001;
    % Number of sampled points to be generated
    H = 500;
    delta = 0.05; % Lever de uncertainty or perturbation
    
    robust_function = -((1/((2*pi)^0.5))*exp(-0.5*((((x(1)-1.5)*(x(1)-1.5)+(x(2)-1.5)*(x(2)-1.5))/0.5).^1))...
         +(2/((2*pi)^0.5))*exp(-0.5*((((x(1)-0.5)*(x(1)-0.5)+(x(2)-0.5)*(x(2)-0.5))/i).^1)));
    for k=1:H
        % Add random sample to original data
        x_perturbed = x + delta;
        F(k) = -((1/((2*pi)^0.5))*exp(-0.5*((((x_perturbed(1)-1.5)*(x_perturbed(1)-1.5)+(x_perturbed(2)-1.5)*(x_perturbed(2)-1.5))/0.5).^1))...
               +(2/((2*pi)^0.5))*exp(-0.5*((((x_perturbed(1)-0.5)*(x_perturbed(1)-0.5)+(x_perturbed(2)-0.5)*(x_perturbed(2)-0.5))/i).^1)));
    end
    
    % Calculate Expected Measure  $E(\vec{x}) = \frac{1}{\left\lvert B_\delta(\vec{X}) \right\rvert} \int_{\vec{y}\epsilon B_\delta (\vec{X})} f(\vec{y})dy$
    % But we approxmate it using   $E(\vec{x}) = \frac{1}{H} \sum_{i = 1}^H  f(\vec{x} + \vec{\delta_{i}})$
    expected_objective = (sum(F))/(H);
end